USE Movie_Theatre_DBS_Project;

-- Create customer feedback text table(multivalued)
CREATE TABLE Feedback_text
(
  Feedback_ID INT,
  FOREIGN KEY(Feedback_ID ) REFERENCES Customer_Feedback(Feedback_ID ),
  Feedback_Text1 VARCHAR(70),
  Feedback_Text2 VARCHAR(70),
  Feedback_Text3 VARCHAR(70),
);