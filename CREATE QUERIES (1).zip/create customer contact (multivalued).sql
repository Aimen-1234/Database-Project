USE Movie_Theatre_DBS_Project;

-- Create Customer_Contact_No table
CREATE TABLE Cust_Contact_Numberr
(
  Customer_ID INT,
  FOREIGN KEY(Customer_ID) REFERENCES Customer(Customer_ID),
  Customer_Contact_No1 VARCHAR(30),
   Customer_Contact_No2 VARCHAR(30),
);