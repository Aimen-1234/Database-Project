USE Movie_Theatre_DBS_Project;

-- Create Website table
CREATE TABLE Online_Movie_Ticket_Booking_Website (
    Website_ID VARCHAR(20) PRIMARY KEY,
    Title VARCHAR(100),
    Domian VARCHAR(15),
	URL VARCHAR(25),
	Content VARCHAR(30),
	Customer_ID INT,
	FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);