USE Movie_Theatre_DBS_Project;

-- Create customer feedback table
CREATE TABLE Customer_Feedback (
    Feedback_ID INT PRIMARY KEY,
    Rating INT,
	Customer_ID INT,
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID),
    Movie_ID INT,
	FOREIGN KEY (Movie_ID) REFERENCES Movie(Movie_ID),
);