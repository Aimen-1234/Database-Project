USE Movie_Theatre_DBS_Project;

-- Create Customer table
CREATE TABLE Customer (
    Customer_ID INT PRIMARY KEY,
    FirstName VARCHAR(100),
	LastName VARCHAR(100),
	Street_Number VARCHAR(30),
	City VARCHAR(30),
	State VARCHAR(30),
	Gender VARCHAR(30),
	Age INT,
	Login_ID INT ,
	FOREIGN KEY (Login_ID) REFERENCES Login(Login_ID),
);