USE Movie_Theatre_DBS_Project;

-- Create Cinema table
CREATE TABLE Cinemaa 
(
  Cinema_ID VARCHAR(20) PRIMARY KEY,
  Cinema_Name VARCHAR(100),
  City VARCHAR(30),
  State VARCHAR(30),
  Street_Number VARCHAR(30),
  NoOfSeats VARCHAR(20),
   Movie_ID INT,
   FOREIGN KEY( Movie_ID) REFERENCES Movie( Movie_ID)
);