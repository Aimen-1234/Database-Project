USE Movie_Theatre_DBS_Project;

-- Create Schedule table
CREATE TABLE Schedule 
(
   Schedule_ID VARCHAR(20) PRIMARY KEY,
   Show_Date Date,
   Starting_Time VARCHAR(20),
   Ending_Time VARCHAR(20),
   Movie_ID INT,
   FOREIGN KEY( Movie_ID) REFERENCES Movie( Movie_ID)
);