USE Movie_Theatre_DBS_Project;

-- Create Movie_Stars table (multivlued)
CREATE TABLE Movie_Stars
(
  Movie_ID INT,
  FOREIGN KEY(Movie_ID) REFERENCES Movie(Movie_ID),
  Lead_role VARCHAR(25),
  Side_role VARCHAR(20),
  Supporting_role VARCHAR(30),
  Villain VARCHAR(25),
);