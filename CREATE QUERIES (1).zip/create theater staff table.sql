USE Movie_Theatre_DBS_Project;

-- Create Theater_Staff table
CREATE TABLE Theatre_Staff
(
   Staff_ID VARCHAR(15) PRIMARY KEY,
   Staff_Name VARCHAR(100),
   Staff_Position VARCHAR(30),
   Staff_Email VARCHAR(50),
   Cinema_ID VARCHAR(20),
   FOREIGN KEY (Cinema_ID) REFERENCES Cinema(Cinema_ID)
);