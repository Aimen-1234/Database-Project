USE Movie_Theatre_DBS_Project;

-- Create Admin table
CREATE TABLE Admin
(
   Admin_ID VARCHAR(20) PRIMARY KEY,
   Admin_Name VARCHAR(50),
   Admin_Contact_No VARCHAR(15),
   Admin_Role VARCHAR(50),
   Admin_Pasword VARCHAR(30),
    Website_ID VARCHAR(20),
   FOREIGN KEY (Website_ID ) REFERENCES Online_Movie_Ticket_Booking_Website(Website_ID )
);