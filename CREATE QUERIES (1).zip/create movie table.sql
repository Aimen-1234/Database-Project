USE Movie_Theatre_DBS_Project;

-- Create Movie table
CREATE TABLE Movie
(
  Movie_ID INT PRIMARY KEY,
  Move_Title VARCHAR(50),
  Duration VARCHAR(40),
  Movie_Desc VARCHAR(20),
  Language VARCHAR(30),
  Customer_ID INT,
  FOREIGN KEY(Customer_ID) REFERENCES Customer(Customer_ID),
);