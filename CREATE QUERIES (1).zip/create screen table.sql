USE Movie_Theatre_DBS_Project;

-- Create table Screen
CREATE TABLE Screen (
    Screen_ID VARCHAR(20) PRIMARY KEY,
    Screen_Name VARCHAR(100),
    Screen_No INT,
    Cinema_ID VARCHAR(20),
    FOREIGN KEY (Cinema_ID) REFERENCES Cinema(Cinema_ID),
	Schedule_ID VARCHAR(20),
	FOREIGN KEY (Schedule_ID) REFERENCES  Schedule (Schedule_ID),
);