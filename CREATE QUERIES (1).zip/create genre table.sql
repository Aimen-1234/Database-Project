USE Movie_Theatre_DBS_Project;

-- Create Movie table
CREATE TABLE Genre
(
  Name VARCHAR(30),
  Movie_ID INT,
  FOREIGN KEY( Movie_ID) REFERENCES Movie( Movie_ID)
);