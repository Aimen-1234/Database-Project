USE Movie_Theatre_DBS_Project;

--Create Login table
CREATE TABLE Login
(
  Login_ID INT PRIMARY KEY,
  FirstName VARCHAR(20) NOT NULL,
  LastName VARCHAR(20) ,
  Email_Address VARCHAR(50),
  Password VARCHAR(30) NOT NULL,
  Confirm_Password VARCHAR(30) NOT NULL,
  Gender VARCHAR(10),
);
