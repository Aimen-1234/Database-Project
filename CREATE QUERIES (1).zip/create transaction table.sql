USE Movie_Theatre_DBS_Project;

-- Create transaction table
CREATE TABLE Transaction1(
    Transaction_ID INT PRIMARY KEY,
    Transaction_Date DATE,
    Transaction_Amount DECIMAL(10,2),
	Payment_Method VARCHAR(30),
	Customer_ID INT,
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID),
    Movie_ID INT,
	FOREIGN KEY (Movie_ID) REFERENCES Movie(Movie_ID)
);