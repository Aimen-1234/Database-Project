INSERT INTO Transaction1  VALUES
(1, '2024-05-20', 2550, 'Credit Card', 01, 1),
(2, '2024-05-20', 3000, 'Debit Card', 02, 2),
(3, '2024-05-21', 2068, 'Cash', 03, 3),
(4, '2024-05-21', 1500, 'Credit Card', 04, 4),
(5, '2024-05-22', 1800, 'Debit Card', 05, 5);