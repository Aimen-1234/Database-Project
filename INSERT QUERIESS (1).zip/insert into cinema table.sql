INSERT INTO Cinemaa VALUES
(1, 'Cinepax Lahore', 'Lahore', 'Punjab', 'street#4','4', 1),
(2, 'Nueplex Cinema Karachi', 'Karachi', 'Sindh', 'DHA Phase 8','5', 2),
(3, 'Cinegold Plex Islamabad', 'Islamabad', 'Islamabad Capital Territory', 'Bahria Enclave','7', 3),
(4, 'Cine Star Cinema Multan', 'Multan', 'Punjab', 'Nishtar Road','6', 4),
(5, 'Cinepax Rawalpindi', 'Rawalpindi', 'Punjab', '1st Floor, Giga Mall','2', 5);