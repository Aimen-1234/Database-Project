INSERT INTO Movie  VALUES
(1, 'Inception', '2h 28m', 'thriller', 'English', 01),
(2, 'The Dark Knight','3h 15m', 'Batman Begins', 'Spanish',02),
(3, 'Die Hard','3h 4m','Action-packed ','Turkey',03),
(4, 'Parasite', '2h 12m', 'dark comedy', 'Korean', 04),
(5, 'Dangal', '2h 41m', 'sports biographical', 'Hindi',05);