INSERT INTO Customer VALUES
(01, 'Ali', 'Khan', '123', 'Karachi', 'Sindh', 'Male', 30, 1),
(02, 'Fatima', 'Ahmed', '456', 'Lahore', 'Punjab', 'Female', 25, 2),
(03, 'Muhammad', 'Hussain', '789', 'Islamabad', 'Islamabad Capital Territory', 'Male', 35, 3),
(04, 'Ayesha', 'Malik', '1011', 'Rawalpindi', 'Punjab', 'Female', 28, 4),
(05, 'Ahmed', 'Ali', '1213', 'Faisalabad', 'Punjab', 'Male', 40, 5);