INSERT INTO Login VALUES
(1,'Danish','Khan','danish@gmail.com','F23','F23','Male'),
(2, 'Fatima', 'Ahmed', 'fatima@gmail.com', 'password2', 'password2', 'Female'),
(3, 'Muhammad', 'Hussain', 'hussain@gmail.com', 'password3', 'password3', 'Male'),
(4, 'Ayesha', 'Malik', 'ayesha@gmail.com', 'password4', 'password4', 'Female'),
(5, 'Ahmed', 'Khan', 'ahmed@gmail.com', 'password5', 'password5', 'Male'),
(6, 'Sana', 'Ali', 'sana@gmail.com', 'password6', 'password6', 'Female'),
(7, 'Hassan', 'Raza', 'hassan@gmail.com', 'password7', 'password7', 'Male'),
(8, 'Zainab', 'Khan', 'zainab@gmail.com', 'password8', 'password8', 'Female'),
(9, 'Bilal', 'Akhtar', 'bilal@gmail.com', 'password9', 'password9', 'Male'),
(10, 'Nimra', 'Shah', 'nimra@gmail.com', 'password10', 'password10', 'Female');