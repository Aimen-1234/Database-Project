INSERT INTO Genre VALUES
('Action',1),
('Comedy',2),
('Mystery',3),
('Horror',4),
('Fantasy',5);