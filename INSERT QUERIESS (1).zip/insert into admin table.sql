INSERT INTO Admin VALUES
('A001', 'Ali Ahmed', '923001234567', 'Website Administrator', 'password123','W001');

