INSERT INTO Movie_Stars VALUES
(1, 'Leonardo DiCaprio', 'Joseph Gordon-Levitt', 'Ellen Page', 'Cillian Murphy'),
(2, 'Christian Bale', 'Heath Ledger', 'Aaron Eckhart', 'Tom Hardy'),
(3, 'Bruce Willis','NULL','NULL','Alan Rickman'),
(4, 'Song Kang-ho','NULL','Cho Yeo-jeong', 'Lee Sun-kyun'),
(5, 'Aamir Khan','NULL', 'Sakshi Tanwar','NULL');