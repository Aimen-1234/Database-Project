INSERT INTO Feedback_text VALUES
(1, 'Great experience! Loved the movie selection.', 'The ticket booking process was smooth', 'The theater ambiance was fantastic.'),
(2, 'Movie was okay, could have been better.', 'The snack options could be improved.', 'Overall, a good experience.'),
(3, 'Enjoyed the movie night with friends.', 'The staff was friendly and helpful.', 'Looking forward to visiting again.'),
(4, 'The seating was comfortable.', 'The sound system needs an upgrade.', 'Overall, a satisfactory experience.'),
(5, 'Great movie! Really enjoyed it.','The cinema experience was bad','overall, ok');