INSERT INTO Theatre_Staff VALUES
('F23605066', 'Ali Ahmed', 'Manager', 'ali@example.com', 01),
('F23605088', 'Arjia Ashraf', 'Ticketing Staff', 'arjia@example.com', 02),
('F23605098', 'Sonia', 'Ticketing Staff2', 'sonia@example.com', 03),
('F23605065', 'Ume Aimen', 'Concession Staff', 'aimen@example.com', 04),
('F23605087', 'Afnan Ahmed', 'Projectionist', 'afnan@example.com', 05);