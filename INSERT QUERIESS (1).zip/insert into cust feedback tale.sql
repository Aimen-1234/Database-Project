INSERT INTO Customer_Feedback VALUES
(1, 4, 01, 1),
(2, 5, 02, 2),
(3, 1, 03, 3),
(4, 4, 04, 4),
(5, 3, 05, 5);