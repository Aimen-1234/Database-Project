INSERT INTO Screen VALUES
('S01', 'Screen 1', 162, 1, 1),
('S02', 'Screen 2', 154, 2, 2),
('S03', 'Screen 1', 165, 3, 3),
('S04', 'Screen 2', 132, 4, 4),
('S05', 'Screen 1', 109, 5, 5);