INSERT INTO Online_Movie_Ticket_Booking_Website VALUES
('W001', 'MovieBooker', 'moviebooker.com', 'www.moviebooker.com', 'Movie ticket booking platform', 01);